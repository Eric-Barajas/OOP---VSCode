import java.util.ArrayList;

public class Order{
    // attributes
    public String name;
    public double total;
    public boolean ready;
    public ArrayList<Item> items = new ArrayList<>();
    // constructors

    // getters/setters/other methods
}