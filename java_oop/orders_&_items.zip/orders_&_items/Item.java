public class Item{
    // attributes
    public String name;
    public double price;
    // constructors

    // getters/setters/other methods
    
}