public class Hello{
    public static void main(String[] args){
        System.out.println("My name is Eric Barajas");
        System.out.println("I am 19 years old");
        System.out.println("My hometown is Berkeley, CA");
    }
}