public class CafeUtil{
    // public int getStreakGoal(){
    //     int sum = 0;
    //     for(int i = 1; i < 11; i++){
    //         sum += i;
    //     }
    // return sum;
    // }


    // public double getOrderTotal(double[] prices){
    //     int sum = 0;
    //     for(int i = 0; i < getOrderTotal.size(); i++){
    //         sum += i;
    //     }
    // return sum;
    // }

    // public void displayMenu(ArrayList<String> menuitems){
    //     for (int i = 0; i < menu.size(); i++){
    //         System.out.println(i)
    //         System.out.println(String name = myArray.get(0));
    //     }
    // }

    public void addCustomer(ArrayList<String> customers){
        System.out.println("Please enter your name:");
        String userName = System.console().readLine();
        System.out.println("Hello, [username here]!");
        System.out.println("There are 0 people in front of you");
        System.out.println(myArray.add("[username here]")); 

    }

}